#ifndef MULTIHASH_H
#define MULTIHASH_H
#include <iostream>
#include <cmath> 
using namespace std;


unsigned int computeValue(int k, int maxrow, float A);




#endif
